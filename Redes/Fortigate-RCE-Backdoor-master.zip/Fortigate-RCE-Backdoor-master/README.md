# Fortigate-RCE-Backdoor

This is a POC for the Fortigate OS Backdoor found in version 4.x up to 5.0.7

Run this POC using:

python FGbackdoor.py Fortigate-Device-IP

pyHacks
=======

Python Scripts for Hacking .

Python Scripts used in the "Hacking con Python" series.
Check: http://thehackerway.com
